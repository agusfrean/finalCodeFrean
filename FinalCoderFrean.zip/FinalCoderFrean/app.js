// Arrays con las opciones de productos
const formaciones = [
    { id: 1, nombre: 'Instructorado en Hatha Yoga', precio: 100000 },
    { id: 2, nombre: 'Instructorado en Yoga Terapéutico', precio: 120000 },
    { id: 3, nombre: 'Instructorado en Yoga para el Embarazo', precio: 130500 }
];

const clases = [
    { id: 4, nombre: 'Hatha Yoga', precio: 12000, horario: 'Martes de 10 a 12hs' },
    { id: 5, nombre: 'Vinyasa Yoga', precio: 15000, horario: 'Martes de 10 a 12hs' },
    { id: 6, nombre: 'Ashtanga Yoga', precio: 18000, horario: 'Martes de 10 a 12hs' }
];

// Carrito inicializado desde el localStorage si existe, o vacío
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

// Función para agregar elementos al carrito
function agregarAlCarrito(producto) {
    carrito.push(producto);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    mostrarCarrito();
}

// Función para mostrar el carrito y el total de la compra
function mostrarCarrito() {
    const cartDiv = document.getElementById('cart');
    cartDiv.innerHTML = ''; // Limpiar el contenido del carrito
    let total = 0; // Inicializar total en 0

    carrito.forEach((item, index) => {
        const itemDiv = document.createElement('div');
        itemDiv.textContent = `${item.nombre} - $${item.precio}`;
        
        // Botón para eliminar el producto del carrito
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Eliminar';
        removeButton.style.marginLeft = '10px';
        removeButton.addEventListener('click', () => {
            eliminarDelCarrito(index);
        });

        itemDiv.appendChild(removeButton);
        cartDiv.appendChild(itemDiv);

        // Sumar el precio de cada producto al total
        total += item.precio;
    });

    // Mostrar el total de la compra
    const totalDiv = document.createElement('div');
    totalDiv.textContent = `Total: $${total}`;
    totalDiv.style.marginTop = '10px'; // Añadir un poco de espacio antes del total
    cartDiv.appendChild(totalDiv);
}

// Función para eliminar un elemento del carrito
function eliminarDelCarrito(index) {
    carrito.splice(index, 1); // Elimina el producto del array
    localStorage.setItem('carrito', JSON.stringify(carrito)); // Actualiza el localStorage
    mostrarCarrito(); // Actualiza el DOM
}

// Función para limpiar el carrito (y el localStorage)
function finalizarCompra() {
    alert('Compra finalizada. ¡Gracias!');
    carrito = [];
    localStorage.removeItem('carrito');
    mostrarCarrito();
}

// Eventos de los botones principales
document.getElementById('btnFormaciones').addEventListener('click', () => {
    mostrarOpciones(formaciones);
});

document.getElementById('btnClases').addEventListener('click', () => {
    mostrarOpciones(clases, true);
});

// Función para mostrar las opciones de productos
function mostrarOpciones(opciones, esClase = false) {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = ''; // Limpiar opciones previas
    opciones.forEach(opcion => {
        const button = document.createElement('button');
        button.textContent = opcion.nombre;
        button.addEventListener('click', () => {
            agregarAlCarrito(opcion);
            if (esClase) {
                alert(`Clase de ${opcion.nombre} agregada. Horario: ${opcion.horario}`);
            } else {
                alert(`${opcion.nombre} agregado al carrito.`);
            }
        });
        mainContent.appendChild(button);
    });
}

// Evento para finalizar la compra
document.getElementById('finalizePurchase').addEventListener('click', finalizarCompra);

// Mostrar carrito al cargar la página
mostrarCarrito();
